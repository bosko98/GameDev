using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MyScore : MonoBehaviour
{
    public int score = 0;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("5pts"))
        {
            score += 5;
            Debug.Log("Score: " + score);
        }
        else if (other.gameObject.CompareTag("10pts"))
        {
            score += 10;
            Debug.Log("Score: " + score);
        }
        else if (other.gameObject.CompareTag("20pts"))
        {
            score += 20;
            Debug.Log("Score: " + score);
        }
    }
}
