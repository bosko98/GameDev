using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class JumpScript : MonoBehaviour
{
    public float jumpForce = 5f; // the force with which the character will jump

    Rigidbody rb; // reference to the Rigidbody component

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            rb.velocity = new Vector3(rb.velocity.x, jumpForce, rb.velocity.z);
        }
    }
}
