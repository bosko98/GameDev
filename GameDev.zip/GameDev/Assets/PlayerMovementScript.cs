using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovementScript : MonoBehaviour
{
    public float speed = 5f; // The player's movement speed

    private Rigidbody2D rb; // The player's rigidbody component
    private SpriteRenderer spriteRenderer; // The player's sprite renderer component
    private bool canMove = true; // Flag indicating whether the player is allowed to move or not

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb.constraints = RigidbodyConstraints2D.FreezeRotation;
    }

    void FixedUpdate()
    {
        if (canMove) // Check if the player is allowed to move
        {
            // Get input from the horizontal and vertical axes
            float moveHorizontal = Input.GetAxis("Horizontal");
            float moveVertical = Input.GetAxis("Vertical");

            // Create a movement vector based on the input and the player's speed
            Vector2 movement = new Vector2(moveHorizontal, moveVertical) * speed;

            // Move the player's rigidbody
            rb.MovePosition(rb.position + movement * Time.fixedDeltaTime);

            // Flip the player's sprite if they are moving to the right
            if (moveHorizontal > 0)
            {
                spriteRenderer.flipX = true;
            }
            else if (moveHorizontal < 0)
            {
                spriteRenderer.flipX = false;
            }
        }
    }

    // Disable player movement when hit by a certain object
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Enemy") // Change "Obstacle" to the tag of the object that should disable player movement
        {
            canMove = false;
        }
    }
}
