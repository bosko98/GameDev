using UnityEngine;

public class CameraFollowScript : MonoBehaviour
{
    public Transform target; // The target to follow
    public float smoothSpeed = 0.125f; // The smoothness of the camera's movement

    private Vector3 offset; // The offset between the camera and the target

    void Start()
    {
        // Calculate the offset between the camera and the target
        offset = transform.position - target.position;
    }

    void FixedUpdate()
    {
        // Calculate the target position for the camera to move towards
        Vector3 targetPosition = target.position + offset;

        // Smoothly move the camera towards the target position
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, targetPosition, smoothSpeed);
        transform.position = smoothedPosition;
    }
}
