using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaunchCircle : MonoBehaviour
{
    public Rigidbody2D circleRigidbody; 
    public float launchForce = 20f; 
    private bool hasLaunched = false;

    private Vector2 startingPosition;
    private Quaternion startingRotation;

    private void Start()
    {
        startingPosition = circleRigidbody.transform.position;
        startingRotation = circleRigidbody.transform.rotation;
    }

    public void OnLaunchButtonClick()
    {
        if (hasLaunched)
        {
            return;
        }

        circleRigidbody.AddForce(Vector2.up * launchForce, ForceMode2D.Impulse);
        hasLaunched = true; 
    }

    public void ResetCircle()
    {
        circleRigidbody.transform.position = startingPosition;
        circleRigidbody.transform.rotation = startingRotation;

        hasLaunched = false;

        circleRigidbody.velocity = Vector2.zero;
        circleRigidbody.angularVelocity = 0f;
    }

    public void IncreaseForce()
    {
        launchForce += 1;
    } 
    public void DecreaseForce()
    {
        launchForce -= 1;
    }

    
}
