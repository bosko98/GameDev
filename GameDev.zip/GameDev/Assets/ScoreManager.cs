using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public int score;

    private void Start()
    {
        score = 0;
    }

    public void AddScore(int amount)
    {
        score += amount;
    }
}
