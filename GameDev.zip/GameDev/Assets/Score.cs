using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Score : MonoBehaviour
{
    public int score = 0;

    void OnCollisionEnter(Collision col)
    {
        if (col.gameObject.CompareTag("Box"))
        {
            score++;
            Debug.Log("Score: " + score);
        }
    }
}

